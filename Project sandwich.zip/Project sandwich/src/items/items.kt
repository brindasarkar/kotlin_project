package items

class Breads(var cost: Int = 15){   //classes with constructor declaration
}
val Multigrain = Breads(cost = 25)
val Wheat = Breads(cost = 20)
val Honeyoat = Breads(cost = 30)
val Glutenfree = Breads(cost = 35)

class Vegetable(var cost1: Int = 15){   //classes with constructor declaration
}
val Cucumber = Vegetable(cost1 = 10)
val Lettuce = Vegetable(cost1 = 20)
val Capsicum = Vegetable(cost1 = 20)
val Tomato = Vegetable(cost1 = 10)

open class Filling(name: String, price: Int) {   //inheritence //base class
    init {
        println("$name cost : $price")
    }
}
class Chicken(name: String, price: Int): Filling(name, price) //derived class
class Egg(name: String, price: Int): Filling(name, price)  //derived class
class Tuna(name: String, price: Int): Filling(name, price)  //derived class

data class Sauces(var cost2: Int) //data class
var Mustard = Sauces(10)
var SouthWest = Sauces(15)
var Mayonnaise = Sauces(20)

enum class Cheese(var price1: Int) //enum class
{
    Cheddar(35),
    Mozzarella(price1 = 40);
}





