package items

fun main(args: Array<String>) {
    //var s1: Int =0
    println("Choose among the following filling: 1.Chicken 2.Egg 3.Tuna")
    var s : String? = readLine()
    if (s != null) {       //null check
        if(s.toInt()==1){
            var t1 = Chicken("Chicken", 40)
        }
        if(s.toInt()==2){
            var t1 = Egg("Egg", 40)
        }
        if(s.toInt()==3){
            var t1 = Tuna("Tuna", 40)
        }
    }

    println("Choose one bread type among the following: 1. Multigrain 2. Wheat 3. Honey oat 4. Gluten free")
    var a = readLine()
    if (a != null) {
        //println("${a.toInt()}")
    }
    var a1: Int = 0
    when (a!!.toInt()) {
        1 -> {println("Multigrain bread cost : ${Multigrain.cost}")
            a1 = Multigrain.cost }
        2 -> {println("Wheat bread cost : ${Wheat.cost}")
            a1 = Wheat.cost }
        3 -> {println("Honey oat bread cost : ${Honeyoat.cost}")
            a1 = Honeyoat.cost }
        4 -> {println("Gluten free bread cost : ${Glutenfree.cost}")
            a1 = Glutenfree.cost }
        else -> {println("Enter the correct option")
            a1 = 0}
    }

    println("\nChoose one vegetable among the following: 1. Cucumber 2. Lettuce 3. Capsicum 4. Tomato")
    var b = readLine()
    if (b != null) {
        //println("${b.toInt()}")
    }
    var b1: Int = 0
    when (b!!.toInt()) {
        1 -> {println("Cucumber cost : ${Cucumber.cost1}")
            b1 = Cucumber.cost1}
        2 -> {println("Lettuce cost : ${Lettuce.cost1}")
            b1 = Lettuce.cost1}
        3 -> {println("Capsicum cost : ${Capsicum.cost1}")
            b1 = Capsicum.cost1}
        4 -> {println("Tomato cost : ${Tomato.cost1}")
            b1 = Tomato.cost1}
        else -> {println("Enter the correct option")
            b1 =0}
    }

    println("\nChoose one Sauce among the following: 1. Mustard 2. Chipotle Southwest 3. Mayonnaise")
    var c = readLine()
    var n1: Int =0
    if (c != null) {
        // println("${c.toInt()}")
    }
    when (c!!.toInt()) {
        1 -> {println("Mustard cost : ${Mustard.cost2}")
            n1 = Mustard.cost2}
        2 -> {println("Chipotle Southwest cost : ${SouthWest.cost2}")
            n1 = SouthWest.cost2}
        3 -> {println("Mayonnaise cost : ${Mayonnaise.cost2}")
            n1 = Mayonnaise.cost2 }
        else -> {println("Enter the correct option")
            n1 = 0 }
    }

    println("Choose the type of cheese: 1. Cheddar 2. Mozzarella")
    var d1:  Int =0
    var d : String? = readLine()
    if (d != null) {       //null check
        if(d.toInt()==1){
            Cheese.Cheddar
            println("Cheddar cheese cost: ${Cheese.Cheddar.price1}")
            d1 = Cheese.Cheddar.price1
        }
        else{
            Cheese.Mozzarella
            println("Mozzarella cheese cost: ${Cheese.Mozzarella.price1}")
            d1 = Cheese.Mozzarella.price1
        }
    }

    var c1: Int =40
    //lamba
    val sum: (Int, Int, Int, Int, Int) -> Int = { w:Int, x: Int, y: Int, z: Int, v: Int -> x + y + w + z + v }
    val sum1 = sum(a1, b1, n1, d1, c1)
    println("The total cost of the Sandwich is $sum1")

    println("Enter the amount paid in cash")
    var m: Int? = readLine()?.toInt()
    var change = m!! -sum1
    println("The change is $change")

}





